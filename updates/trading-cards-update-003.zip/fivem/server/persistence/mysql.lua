RushCards.PersistenceAdapters.mysql = function()
    local tableName = Config.Database.Table
    local dbResource = Config.Database.Resource or 'oxmysql'
    local definitionsTable = Config.Database.DefinitionsTable or (tableName .. '_definitions')
    for _, name in ipairs({ tableName, definitionsTable }) do
        if type(name) ~= 'string' or #name > 64 or not name:match('^[%w_]+$') then
            error('Invalid Rush Cards database table name (use letters, digits and underscores, up to 64 characters)')
        end
    end

    local function ensureAvailable()
        return GetResourceState(dbResource) == 'started'
    end

    local function query(sql, params)
        return exports[dbResource]:query_async(sql, params or {})
    end

    local function insert(sql, params)
        return exports[dbResource]:insert_async(sql, params or {})
    end

    local function readDefinition(kind)
        local rows = query(('SELECT `definition_json` FROM `%s` WHERE `definition_key` = ?'):format(definitionsTable), { kind })
        if type(rows) ~= 'table' then error('Could not read Rush Cards definitions from MySQL') end
        if not rows[1] then return nil end
        local ok, decoded = pcall(json.decode, rows[1].definition_json)
        if not ok or type(decoded) ~= 'table' then
            error(('Invalid MySQL %s data; restore the database record before restarting'):format(kind))
        end
        return decoded
    end

    local function loadDefinition(kind, seedFile)
        local stored = readDefinition(kind)
        if stored ~= nil then return stored end
        local raw = LoadResourceFile(GetCurrentResourceName(), seedFile)
        local ok, decoded = pcall(json.decode, raw or '')
        if not ok or type(decoded) ~= 'table' then
            error(('Cannot import %s: %s is missing or invalid'):format(kind, seedFile))
        end
        -- Only insert an absent key. An existing database definition always wins,
        -- including an intentionally empty list and simultaneous first starts.
        local result = query(('INSERT IGNORE INTO `%s` (`definition_key`, `definition_json`) VALUES (?, ?)'):format(definitionsTable), { kind, raw })
        if result == nil then error(('Could not import %s into MySQL'):format(kind)) end
        stored = readDefinition(kind)
        if stored == nil then error(('MySQL %s import was not persisted'):format(kind)) end
        print(('[rush-tradingcards] imported %s from %s into %s'):format(kind, seedFile, definitionsTable))
        return stored
    end

    local function saveDefinition(kind, data)
        local ok, result = pcall(function()
            return query(('INSERT INTO `%s` (`definition_key`, `definition_json`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `definition_json` = VALUES(`definition_json`)'):format(definitionsTable), { kind, json.encode(data) })
        end)
        if not ok or result == nil then
            print(('[rush-tradingcards] MySQL %s save failed: %s'):format(kind, tostring(result)))
            return false, ('Could not save %s to MySQL. Check the server database logs.'):format(kind)
        end
        return true
    end

    return {
        name = 'mysql',
        init = function()
            if not ensureAvailable() then
                error(('MySQL persistence selected but %s is not started'):format(dbResource))
            end
            if Config.Database.AutoCreateSchema then
                query(([=[
                    CREATE TABLE IF NOT EXISTS `%s` (
                      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                      `owner_identifier` VARCHAR(96) NOT NULL,
                      `instance_id` VARCHAR(96) NOT NULL,
                      `card_key` VARCHAR(160) NOT NULL,
                      `card_id` VARCHAR(160) NULL,
                      `variant_id` VARCHAR(180) NULL,
                      `card_json` LONGTEXT NOT NULL,
                      `acquired_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                      PRIMARY KEY (`id`),
                      UNIQUE KEY `ux_instance_id` (`instance_id`),
                      KEY `ix_owner` (`owner_identifier`),
                      KEY `ix_card_key` (`card_key`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
                ]=]):format(tableName))
                query(([=[
                    CREATE TABLE IF NOT EXISTS `%s` (
                      `definition_key` VARCHAR(32) NOT NULL,
                      `definition_json` LONGTEXT NOT NULL,
                      `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                      PRIMARY KEY (`definition_key`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
                ]=]):format(definitionsTable))
            end
            return true
        end,
        loadCatalog = function(file) return loadDefinition('catalog', file) end,
        saveCatalog = function(cards) return saveDefinition('catalog', cards) end,
        loadSets = function(file) return loadDefinition('sets', file) end,
        saveSets = function(sets) return saveDefinition('sets', sets) end,
        addCards = function(owner, cards)
            for _, card in ipairs(cards or {}) do
                insert(([[
                    INSERT INTO `%s`
                    (`owner_identifier`, `instance_id`, `card_key`, `card_id`, `variant_id`, `card_json`)
                    VALUES (?, ?, ?, ?, ?, ?)
                ]]):format(tableName), {
                    owner,
                    card.instanceId,
                    card.cardKey or '',
                    card.baseCardId or card.id,
                    card.variantId,
                    json.encode(card),
                })
            end
            return true
        end,
        getCollection = function(owner)
            local rows = query(([[SELECT `card_json` FROM `%s` WHERE `owner_identifier` = ? ORDER BY `id` DESC]]):format(tableName), { owner }) or {}
            local cards = {}
            for _, row in ipairs(rows) do
                local ok, decoded = pcall(json.decode, row.card_json)
                if ok and decoded then cards[#cards + 1] = decoded end
            end
            return cards
        end,
    }
end
