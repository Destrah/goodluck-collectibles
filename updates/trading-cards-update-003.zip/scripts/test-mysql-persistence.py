"""Run with Python + lupa: python scripts/test-mysql-persistence.py [lupa-directory]."""
import json
from pathlib import Path
import sys
import unittest

if len(sys.argv) > 1:
    sys.path.insert(0, sys.argv.pop(1))
from lupa.lua54 import LuaRuntime, LuaError

ROOT = Path(__file__).resolve().parents[1]

class PersistenceTests(unittest.TestCase):
    def setUp(self):
        self.db, self.writes, self.queries = {}, [], []
        self.fail_write = self.fail_read = self.race = False
        self.files = {
            'data/catalog.json': json.dumps([
                {'id': 'one', 'title': 'Original', 'image': 'https://example.com/art.png', 'imagePositionX': 20,
                 'variants': [{'id': 'print', 'name': 'Regular', 'rarityKey': 'common', 'layout': 'classic'}]},
                {'id': 'two', 'title': 'Second', 'variants': [{'id': 'second', 'rarityKey': 'common'}]},
            ]),
            'data/sets.json': json.dumps([{'id': 'base', 'name': 'Base', 'cardIds': ['one', 'two']}]),
        }
        self.boot()

    def boot(self, mode='mysql'):
        self.lua = LuaRuntime(unpack_returned_tuples=True)
        g = self.lua.globals()
        g.test_query = self.query
        g.test_encode = lambda value: json.dumps(self.to_python(value))
        g.test_decode = lambda value: self.lua.table_from(json.loads(value), recursive=True)
        g.test_load = lambda resource, file: self.files.get(file)
        g.test_save = self.save_file
        self.lua.execute("""
            Config = { Database = { Table = 'rush_trading_card_instances', AutoCreateSchema = true },
                Catalog = { File = 'data/catalog.json' }, Sets = { File = 'data/sets.json', Default = 'base' } }
            GetResourceState = function() return 'started' end
            GetCurrentResourceName = function() return 'rush-tradingcards' end
            LoadResourceFile = test_load
            SaveResourceFile = test_save
            json = { encode = test_encode, decode = test_decode }
            exports = { oxmysql = { query_async = function(_, sql, params) return test_query(sql, params) end } }
        """)
        self.run_file('fivem/shared/utils.lua')
        self.run_file('fivem/server/persistence/mysql.lua')
        if mode == 'mysql':
            self.lua.execute('RushCards.Persistence = RushCards.PersistenceAdapters.mysql(); RushCards.Persistence.init()')
        else:
            self.lua.execute("RushCards.Persistence = {name = 'json'}")
        self.run_file('fivem/server/sets.lua')
        self.run_file('fivem/server/cards.lua')

    def to_python(self, value):
        if not hasattr(value, 'items'):
            return value
        items = dict(value.items())
        if items and set(items) == set(range(1, len(items) + 1)):
            return [self.to_python(items[i]) for i in range(1, len(items) + 1)]
        return {key: self.to_python(item) for key, item in items.items()}

    def query(self, sql, params):
        self.queries.append(sql)
        if sql.strip().startswith('CREATE'):
            return self.lua.table_from({'affectedRows': 0})
        key = params[1]
        if sql.startswith('SELECT'):
            if self.fail_read:
                raise RuntimeError('Database unavailable')
            rows = [{'definition_json': self.db[key]}] if key in self.db else []
            return self.lua.table_from(rows, recursive=True)
        if self.fail_write:
            raise RuntimeError('Write denied')
        if sql.startswith('INSERT IGNORE'):
            if self.race:
                self.db[key] = '[]'
            self.db.setdefault(key, params[2])
        else:
            self.db[key] = params[2]
        return self.lua.table_from({'affectedRows': 1})

    def save_file(self, resource, file, value, length):
        self.writes.append(file)
        self.files[file] = value
        return True

    def run_file(self, name):
        self.lua.execute((ROOT / name).read_text(encoding='utf-8'))

    def edit_card(self, title):
        self.lua.globals().new_title = title
        return self.lua.execute('local card = RushCards.Cards.getCatalog()[1]; card.title = new_title; return RushCards.Cards.saveCard(card)')

    def test_import_once_and_restart_uses_database(self):
        self.assertEqual(set(self.db), {'catalog', 'sets'})
        self.assertEqual(self.writes, [])
        self.assertTrue(self.edit_card('Database edit'))
        self.files['data/catalog.json'] = 'broken seed should be ignored'
        self.files['data/sets.json'] = 'broken seed should be ignored'
        self.boot()
        self.assertEqual(self.lua.eval('RushCards.Cards.getCatalog()[1].title'), 'Database edit')
        self.assertEqual(self.lua.eval('RushCards.Cards.resolve("one", "print").imagePositionX'), 20)

    def test_set_save_and_card_delete_persist(self):
        self.assertTrue(self.lua.execute('local sets = RushCards.Sets.getAll(); sets[1].name = "Edited set"; return RushCards.Sets.save(sets)'))
        self.assertTrue(self.lua.execute('return RushCards.Cards.deleteCard("two")'))
        self.boot()
        self.assertEqual(self.lua.eval('RushCards.Sets.getAll()[1].name'), 'Edited set')
        self.assertEqual(self.lua.eval('#RushCards.Cards.getCatalog()'), 1)
        self.assertEqual(self.writes, [])

    def test_catalog_save_and_new_print_snapshot(self):
        self.lua.execute('old = RushCards.Cards.resolve("one", "print")')
        self.assertTrue(self.edit_card('New print'))
        self.assertEqual(self.lua.eval('old.title'), 'Original')
        self.assertEqual(self.lua.eval('RushCards.Cards.resolve("one", "print").title'), 'New print')
        self.assertTrue(self.lua.execute('return RushCards.Cards.saveCatalog(RushCards.Cards.getCatalog())'))

    def test_failed_writes_leave_memory_and_json_unchanged(self):
        original = dict(self.db)
        self.fail_write = True
        result = self.edit_card('Must not save')
        self.assertFalse(result[0])
        self.assertIn('MySQL', result[1])
        self.assertFalse(self.lua.execute('local sets = RushCards.Sets.getAll(); sets[1].name = "Bad"; return RushCards.Sets.save(sets)')[0])
        self.assertFalse(self.lua.execute('return RushCards.Cards.deleteCard("two")')[0])
        self.assertEqual(self.lua.eval('RushCards.Cards.getCatalog()[1].title'), 'Original')
        self.assertEqual(self.lua.eval('RushCards.Sets.getAll()[1].name'), 'Base')
        self.assertEqual(self.db, original)
        self.assertEqual(self.writes, [])

    def test_empty_database_definition_does_not_reimport(self):
        self.db['catalog'] = '[]'
        self.boot()
        self.assertEqual(self.lua.eval('#RushCards.Cards.getCatalog()'), 0)

    def test_read_failures_and_corruption_do_not_fallback(self):
        self.fail_read = True
        with self.assertRaises(Exception):
            self.boot()
        self.fail_read = False
        self.db['catalog'] = 'invalid'
        with self.assertRaises(LuaError):
            self.boot()
        self.assertEqual(self.writes, [])

    def test_import_race_uses_existing_row(self):
        self.db.clear()
        self.race = True
        self.boot()
        self.assertEqual(self.lua.eval('#RushCards.Cards.getCatalog()'), 0)
        self.assertEqual(self.db['catalog'], '[]')

    def test_json_mode_keeps_file_storage(self):
        self.boot(mode='json')
        self.assertTrue(self.edit_card('JSON edit'))
        self.assertTrue(self.lua.execute('local sets = RushCards.Sets.getAll(); sets[1].name = "JSON set"; return RushCards.Sets.save(sets)'))
        self.assertIn('data/catalog.json', self.writes)
        self.assertIn('data/sets.json', self.writes)
        self.assertEqual(json.loads(self.db['catalog'])[0]['title'], 'Original')

if __name__ == '__main__':
    unittest.main()
